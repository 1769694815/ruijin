Not 1.7.1 but latest [master](https://github.com/develar/osslsigncode) is used because of 
* [Speed up checksum calculation](https://sourceforge.net/p/osslsigncode/patches/9/).

Notes:

* osslsigncode requires openssl 1.0, so, we bundle openssl 1.0 lib.